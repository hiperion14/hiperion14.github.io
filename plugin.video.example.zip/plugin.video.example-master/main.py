import routing
import sys
from urllib.parse import urlencode, parse_qsl
from xbmcgui import ListItem, Dialog
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl
import scraper

plugin = routing.Plugin()

searcher = scraper.Searcher()

directories = {
    'Peliculas': {
        'Destacadas': {

        },
        'Recientes': {

        },
        'Populares': {

        },
        'Buscar': {

        }
    },
    'Series': {
        'Recientes': {
            'Otros': {},
            'Nosotros': {}
        },
        'Mas vistas': {

        }
    }
}


@plugin.route('/')
def index():
    for key in directories:
        addDirectoryItem(plugin.handle, plugin.url_for(show_directory, f"/dir/{key}"), ListItem(key), True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category_id>')
def show_category(category_id):
    addDirectoryItem(plugin.handle, "", ListItem("Hello category %s!" % category_id), True)
    endOfDirectory(plugin.handle)


@plugin.route('/peliculas/recientes')
def recientes():
    page = int(plugin.args['query'][0])

    movies = searcher.movies(page, "released")
    for movie in movies:
        item = ListItem(movie.title)
        item.setProperty("IsPlayable", 'true')
        addDirectoryItem(plugin.handle, plugin.url_for(get_source, id=movie.id), item)
    addDirectoryItem(plugin.handle, plugin.url_for(recientes, query=str(page + 1)), ListItem("Siguiente"), True)

    endOfDirectory(plugin.handle)


@plugin.route("/sources")
def get_source():
    sources = searcher.get_sources(plugin.args['id'][0])

    dialog = Dialog()
    ret = dialog.select('Choose a playlist', [str(item) for item in sources])

    if ret >= 0:
        setResolvedUrl(plugin.handle, True, listitem=ListItem(path=searcher.get_source(sources[ret])))


@plugin.route('/peliculas/destacadas')
def destacadas():
    page = int(plugin.args['query'][0])
    movies = searcher.movies(page, "featured")
    for movie in movies:
        item = ListItem(movie.title)
        item.setProperty("IsPlayable", 'true')
        addDirectoryItem(plugin.handle, plugin.url_for(get_source, id=movie.id), item)

    addDirectoryItem(plugin.handle, plugin.url_for(recientes, query=str(page + 1)), ListItem("Siguiente"), True)
    endOfDirectory(plugin.handle)


@plugin.route('/peliculas/populares')
def populares():
    page = int(plugin.args['query'][0])
    movies = searcher.movies(page, "popular")
    for movie in movies:
        item = ListItem(movie.title)
        item.setProperty("IsPlayable", 'true')
        addDirectoryItem(plugin.handle, plugin.url_for(get_source, id=movie.id), item)

    addDirectoryItem(plugin.handle, plugin.url_for(recientes, query=str(page + 1)), ListItem("Siguiente"), True)
    endOfDirectory(plugin.handle)

@plugin.route("/peliculas/resultados")
def resultados():
    dialog = Dialog()
    input_ = dialog.input("Buscar por titulo")
    if len(input_) > 0:
        movies = searcher.search(input_)
        for movie in movies:
            item = ListItem(movie.title)
            item.setProperty("IsPlayable", 'true')
            addDirectoryItem(plugin.handle, plugin.url_for(get_source, id=movie.id), item)
    endOfDirectory(plugin.handle)




@plugin.route('/directory/<path:dir>')
def show_directory(dir):
    path = dir.split("/")[2::]
    last_dir = directories
    for i in path:
        last_dir = last_dir[i]

    if len(last_dir) > 0:
        for key in last_dir:
            if key == "Recientes":
                addDirectoryItem(plugin.handle, plugin.url_for(recientes, query="1"), ListItem(key), True)
            elif key == "Destacadas":
                addDirectoryItem(plugin.handle, plugin.url_for(destacadas, query="1"), ListItem(key), True)
            elif key == "Populares":
                addDirectoryItem(plugin.handle, plugin.url_for(populares, query="1"), ListItem(key), True)
            elif key == "Buscar":
                addDirectoryItem(plugin.handle, plugin.url_for(resultados), ListItem(key), True)
            else:
                addDirectoryItem(plugin.handle, plugin.url_for(show_directory, f"{dir}/{key}"), ListItem(key), True)
    endOfDirectory(plugin.handle)


if __name__ == '__main__':
    plugin.run()
