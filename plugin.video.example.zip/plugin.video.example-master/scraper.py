import time

from bs4 import BeautifulSoup
from urllib import request, parse
import json
import random

import re

import cloudscraper2 as cloudscraper

scraper = cloudscraper.create_scraper()


class watchsb:
    def randString(self, length):
        result = ""
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

        for i in range(length):
            result += letters[random.randint(0, len(letters) - 1)]
        return result

    def encode(self, source):
        video_id = f'{self.randString(12)}||{source}||{self.randString(12)}||streamsb'
        result = ""

        for char in video_id:
            result += '{:x}'.format(ord(char))
        return result

    def get_playable(self):
        print(self.code)
        req4 = request.Request(f"https://sbembed.com/embed-{self.code}.html")
        req4.add_header("user-agent",
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/112.0.0.0 Safari/537.36")
        request.urlopen(req4).read()
        url = f'https://sbembed.com/375664356a494546326c4b797c7c6e756577776778623171737/{self.encode(self.code)}'
        req = request.Request(url)
        req.add_header("user-agent",
                       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/112.0.0.0 Safari/537.36")
        req.add_header("watchsb", "sbstream")
        req.add_header("referer", f"https://sbembed.com/embed-{self.code}.html")
        req.add_header("accept-language", "es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7")
        response = request.urlopen(req)
        content = json.loads(response.read())
        m3u8_url = content['stream_data']['file']
        print(m3u8_url)
        return m3u8_url + "|accept-language=es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7&Origin=https://sbembed.com&Referer=https://sbembed.com/&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36"

    def __init__(self, code):
        self.code = code


class strtpe:

    def __init__(self, url):
        self.url = url


class powvideo:
    def convert_token(self, token):
        r = list(token)[::-1]
        del r[3]

        temp = r[8]
        r[8] = r[6]
        r[6] = temp

        temp = r[2]
        r[2] = r[9]
        r[9] = temp

        temp = r[1]
        r[1] = r[4]
        r[4] = temp

        return ''.join(r)

    def __init__(self, url):
        self.url = url

    def get_playable(self):
        req = request.Request(self.url)
        req.add_header("referer", "https://cinemascampo.tv/")
        req.add_header("user-agent", "curl/8.0.1")
        response = request.urlopen(req).geturl()
        print(response)

        req = request.Request(response.replace("embed", "player"))
        req.add_header("referer", response)
        req.add_header("user-agent", "curl/8.0.1")
        response = request.urlopen(req).read()

        print(response)


class Source:
    def __init__(self, lang, url, server):
        self.lang = lang
        self.url = url
        self.server = server

    def __repr__(self):
        return self.lang + ": " + self.server

    def __str__(self):
        return self.lang + ": " + self.server




class Movie:
    def __init__(self, title, id, thumb):
        self.title = title
        self.id = id
        self.thumb = thumb

    def __repr__(self):
        return f"{self.title}\n{self.id}\n{self.thumb}"

    def get_sources(self):
        return "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"


class Searcher:
    def __init__(self):
        pass

    def player_from_url(self, url):
        parsed = parse.urlparse(url)
        host = parsed.hostname
        print(host)
        if host == "watchsb.com":
            return watchsb(parsed.path.split("-")[-1].split(".")[0])
        elif host == "sbembed.com":
            return watchsb(parsed.path.split("-")[-1].split(".")[0])
        elif host == "sbfast.live":
            return watchsb(parsed.path.split("/")[-1])

    def search(self, query):
        xd = scraper.get(
            f"https://ww1.repelishd.app/search/{query}")
        soup = BeautifulSoup(xd.text, features="html.parser")
        movies = []
        for soup_movie in soup.find(id="movies").find_all(class_="list-movie"):
            title = soup_movie.find(class_="list-title").text.strip()
            id = soup_movie.find("a")['href'].split("/")[-1]
            thumb = soup_movie.find(class_="media-cover")["data-src"]
            movies.append(Movie(title, id, thumb))

        return movies


    def movies(self, page, sorting):
        xd = scraper.get(
            "https://ww1.repelishd.app/peliculas?filter={%22sorting%22:%22" + sorting + "%22,%22idioma%22:%22castellano%22}" + f"&page={page}")
        soup = BeautifulSoup(xd.text, features="html.parser")
        movies = []
        for soup_movie in soup.find_all(class_="list-movie"):
            title = soup_movie.find(class_="list-title").text.strip()
            id = soup_movie.find("a")['href'].split("/")[-1]
            thumb = soup_movie.find(class_="media-cover")["data-src"]
            movies.append(Movie(title, id, thumb))

        return movies

    def get_sources(self, id):
        html = scraper.get(f"https://ww1.repelishd.app/pelicula/{id}").text
        url = re.search(r"var url = '(.*)'", html).groups()[0].replace("embeds", "embed").replace("tmdb", "gen")
        soup = BeautifulSoup(scraper.get(url).text, features="html.parser")
        sources = []
        for movie in soup.find_all(class_="playengos"):
            lang = movie['class'][0]
            print(lang)
            url = f"https://{parse.urlparse(url).hostname}/{movie['player']}"
            if "PlaySB" in url:
                sources.append(Source(lang, url, "PlaySB"))
            elif "STP" in url:
                sources.append(Source(lang, url, "STP"))


        return sources

    def get_source(self, source):
        if "PlaySB" == source.server:
            html = scraper.get(source.url).text
            args = re.search(r'location.href = \"(.*)\"', html).groups()[0]
            url = f"https://{parse.urlparse(source.url).hostname}/{args}"
            dos = self.player_from_url(scraper.get(url).url)
            if dos:
                return dos.get_playable()